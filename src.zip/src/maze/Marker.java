package maze;

public enum Marker {
    WALL,
    OPEN_SPACE,
    START,
    FINISH
}
