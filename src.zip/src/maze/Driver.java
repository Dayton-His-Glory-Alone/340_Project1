package maze;

public class Driver {

	public static void main(String[] args) {
		
		MazeReader maze = new MazeReader();
		
		maze.toString();
	}

}
