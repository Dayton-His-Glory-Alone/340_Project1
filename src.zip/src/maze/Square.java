package maze;

public class Square {

	public String location;
	public Square (char ch) throws Exception {
		
		if (ch=='#') {
			//wall
			location= "wall";
		}
		else if(ch=='.') {
			//open space
			location= "open";
		}
		else if(ch=='o') {
			//start
			location= "start";
		}
		else if(ch=='*') {
			//finish
			location= "finish";
		}
		else {
			throw new IllegalAccessException("invalid character");
		}
		
	}
	
	
	public String toString() {
		
		if (location.equals("wall")) {
			
			return "#";
		}
		else if (location.equals("open")) {
			
			return ".";
		}
		else if (location.equals("start")) {
			return "o";
		}
		else if (location.equals("finish")) {
			return "*";
		}
		else {
			return null;
		}		
	}
}